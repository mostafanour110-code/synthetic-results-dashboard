using SyntheticResultsDashboard.Domain.Entities;

namespace SyntheticResultsDashboard.Application.Contracts;

public interface IClock { DateTimeOffset UtcNow { get; } }

public interface IWorkbookReader
{
    IReadOnlyList<string> InspectAndListVisibleSheets(string fullPath);
    IReadOnlyList<WorkbookRecord> ReadSheet(string fullPath, string sheetName);
}

public interface IReportWriter
{
    byte[] WriteReport(ImportBatch batch, IReadOnlyList<ImportRow> rows);
    byte[] WriteDemoTemplate();
}

public interface ITemporaryFileStore
{
    Task<(string StorageKey, long Length)> SaveAsync(Stream input, CancellationToken cancellationToken);
    bool Exists(string key);
    string Resolve(string key);
    void Delete(string key);
}

public interface IExecutionGate
{
    Task<IAsyncDisposable> EnterAsync(CancellationToken cancellationToken);
}

public interface IAppData
{
    Task<ImportBatch?> FindBatchAsync(Guid id, CancellationToken ct);
    Task<ImportBatch?> LatestCompletedBatchAsync(CancellationToken ct);
    Task AddBatchAsync(ImportBatch batch, CancellationToken ct);
    Task<IReadOnlyDictionary<string, ReferenceEntry>> LookupReferencesAsync(IReadOnlyCollection<string> codes, CancellationToken ct);
    Task<IReadOnlyList<ReferenceEntry>> AllDemoCodesAsync(CancellationToken ct);
    Task AddReferencesAsync(IEnumerable<ReferenceEntry> references, CancellationToken ct);
    Task CompleteAsync(ImportBatch batch, IReadOnlyList<ImportRow> rows, CancellationToken ct);
    Task MarkExpiredAsync(ImportBatch batch, CancellationToken ct);
    Task<IReadOnlyList<ImportBatch>> UploadedBatchesAsync(CancellationToken ct);
    Task<(int Count, IReadOnlyList<ImportRow> Rows)> PageRowsAsync(Guid batchId, RowOutcome? outcome, int page, int pageSize, CancellationToken ct);
    Task<IReadOnlyList<ImportRow>> AllRowsAsync(Guid batchId, CancellationToken ct);
}

public sealed class PublicValidationException(string message) : Exception(message);
