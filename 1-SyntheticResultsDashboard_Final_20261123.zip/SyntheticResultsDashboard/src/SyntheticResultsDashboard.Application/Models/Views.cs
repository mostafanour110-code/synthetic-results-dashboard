using SyntheticResultsDashboard.Domain.Entities;

namespace SyntheticResultsDashboard.Application.Models;

public sealed record RowPage(int Total, int Page, int PageSize, RowOutcome? Filter,
    IReadOnlyList<ImportRow> Rows)
{
    public int Pages => Math.Max(1, (int)Math.Ceiling(Total / (double)PageSize));
}

public sealed record ExportedWorkbook(string FileName, byte[] Data);
