using SyntheticResultsDashboard.Application.Contracts;
using SyntheticResultsDashboard.Application.Models;
using SyntheticResultsDashboard.Domain.Entities;
using SyntheticResultsDashboard.Domain.Validation;

namespace SyntheticResultsDashboard.Application.Services;

public sealed class ResultsService(
    IAppData data, IWorkbookReader reader, IReportWriter writer,
    ITemporaryFileStore files, IExecutionGate gate, IClock clock)
{
    private const long MaxWorkbookBytes = 2L * 1024 * 1024;
    private static readonly IReadOnlyDictionary<string, (string Name, string Department)> Demo =
        new Dictionary<string, (string, string)>(StringComparer.Ordinal)
        {
            ["DEMO-001"] = ("سجل تجريبي أ", "SCI"),
            ["DEMO-002"] = ("سجل تجريبي ب", "ART"),
            ["DEMO-003"] = ("سجل تجريبي ج", "SCI"),
            ["DEMO-004"] = ("سجل تجريبي د", "ART")
        };

    public Task<ImportBatch?> GetBatchAsync(Guid id, CancellationToken ct = default) => data.FindBatchAsync(id, ct);
    public Task<ImportBatch?> GetLatestAsync(CancellationToken ct = default) => data.LatestCompletedBatchAsync(ct);

    public async Task<Guid> UploadAsync(Stream input, string fileName, long declaredSize, CancellationToken ct)
    {
        if (declaredSize is <= 0 or > MaxWorkbookBytes)
            throw new PublicValidationException("حجم الملف غير مسموح. الحد الأقصى 2 ميجابايت.");
        string safeName = SanitizeFileName(fileName);
        if (!safeName.EndsWith(".xlsx", StringComparison.OrdinalIgnoreCase))
            throw new PublicValidationException("يُسمح بملفات XLSX فقط.");
        await using var exclusive = await gate.EnterAsync(ct);
        var stored = await files.SaveAsync(input, ct);
        try
        {
            reader.InspectAndListVisibleSheets(files.Resolve(stored.StorageKey));
            var batch = new ImportBatch
            {
                OriginalFileName = safeName,
                StorageKey = stored.StorageKey,
                FileSizeBytes = stored.Length,
                CreatedAtUtc = clock.UtcNow
            };
            await data.AddBatchAsync(batch, ct);
            return batch.Id;
        }
        catch
        {
            files.Delete(stored.StorageKey);
            throw;
        }
    }

    public async Task<IReadOnlyList<string>> GetSheetsAsync(Guid id, CancellationToken ct)
    {
        var batch = await RequireBatchAsync(id, ct);
        if (batch.Status != BatchStatus.Uploaded)
            throw new PublicValidationException("الدفعة ليست في حالة تسمح باختيار الورقة.");
        if (IsExpired(batch)) throw new PublicValidationException("انتهت صلاحية الملف. ارفع ملفًا جديدًا.");
        if (!files.Exists(batch.StorageKey)) throw new PublicValidationException("الملف المؤقت غير موجود. ارفع ملفًا جديدًا.");
        return reader.InspectAndListVisibleSheets(files.Resolve(batch.StorageKey));
    }

    public async Task AnalyzeAsync(Guid id, string sheetName, CancellationToken ct)
    {
        await using var exclusive = await gate.EnterAsync(ct);
        var batch = await RequireBatchAsync(id, ct);
        if (batch.Status == BatchStatus.Completed)
            throw new PublicValidationException("هذه الدفعة مكتملة بالفعل. ابدأ استيرادًا جديدًا.");
        if (batch.Status != BatchStatus.Uploaded || IsExpired(batch) || !files.Exists(batch.StorageKey))
            throw new PublicValidationException("الملف غير متاح للتحليل. ارفع ملفًا جديدًا.");
        var allowed = reader.InspectAndListVisibleSheets(files.Resolve(batch.StorageKey));
        if (!allowed.Contains(sheetName, StringComparer.Ordinal))
            throw new PublicValidationException("الورقة المختارة غير موجودة ضمن الأوراق المرئية.");

        var original = reader.ReadSheet(files.Resolve(batch.StorageKey), sheetName);
        var checkedRows = WorkbookRules.Validate(original);
        var validCodes = checkedRows.Where(x => x.IsValid)
            .Select(x => x.ReferenceCode).Distinct(StringComparer.Ordinal).ToArray();
        var references = await data.LookupReferencesAsync(validCodes, ct);
        var processed = checkedRows.Select(row =>
        {
            references.TryGetValue(row.ReferenceCode, out var reference);
            var outcome = WorkbookRules.Match(row, reference);
            return new ImportRow
            {
                BatchId = batch.Id,
                SheetRowNumber = row.SheetRowNumber,
                ReferenceCode = row.ReferenceCode,
                DisplayName = row.DisplayName,
                Department = row.Department,
                Score = row.Score,
                ErrorCodes = string.Join('|', row.Errors),
                Outcome = outcome,
                MatchedReferenceId = outcome == RowOutcome.Matched ? reference?.Id : null
            };
        }).ToArray();

        batch.SelectedSheetName = sheetName;
        batch.TotalRows = processed.Length;
        batch.MatchedCount = processed.Count(x => x.Outcome == RowOutcome.Matched);
        batch.NotFoundCount = processed.Count(x => x.Outcome == RowOutcome.NotFound);
        batch.DepartmentMismatchCount = processed.Count(x => x.Outcome == RowOutcome.DepartmentMismatch);
        batch.InvalidCount = processed.Count(x => x.Outcome == RowOutcome.Invalid);
        if (batch.TotalRows != batch.MatchedCount + batch.NotFoundCount + batch.DepartmentMismatchCount + batch.InvalidCount)
            throw new InvalidOperationException("Count invariant violated.");
        batch.CompletedAtUtc = clock.UtcNow;
        batch.Status = BatchStatus.Completed;
        await data.CompleteAsync(batch, processed, ct);
        files.Delete(batch.StorageKey);
    }

    public async Task<RowPage> GetPageAsync(Guid id, RowOutcome? outcome, int page, CancellationToken ct)
    {
        if (page < 1 || page > 100_000)
            throw new PublicValidationException("رقم الصفحة غير صحيح.");
        var batch = await RequireBatchAsync(id, ct);
        if (batch.Status != BatchStatus.Completed)
            throw new PublicValidationException("الدفعة لم يكتمل تحليلها بعد.");
        var result = await data.PageRowsAsync(id, outcome, page, 25, ct);
        return new RowPage(result.Count, page, 25, outcome, result.Rows);
    }

    public async Task<ExportedWorkbook> ExportAsync(Guid id, CancellationToken ct)
    {
        var batch = await RequireBatchAsync(id, ct);
        if (batch.Status != BatchStatus.Completed)
            throw new PublicValidationException("لا يمكن تصدير دفعة غير مكتملة.");
        var rows = await data.AllRowsAsync(id, ct);
        return new ExportedWorkbook($"synthetic-results-{batch.Id:N}"[..26] + ".xlsx", writer.WriteReport(batch, rows));
    }

    public byte[] Template() => writer.WriteDemoTemplate();

    public async Task<int> SeedDemoAsync(CancellationToken ct)
    {
        await using var exclusive = await gate.EnterAsync(ct);
        var current = await data.AllDemoCodesAsync(ct);
        foreach (var entry in current)
        {
            var expected = Demo[entry.ReferenceCode];
            if (entry.DisplayName != expected.Name || entry.Department != expected.Department)
                throw new PublicValidationException("تعارض مع سجل مرجعي موجود؛ لم يتم استبدال البيانات.");
        }
        var missing = Demo.Where(pair => current.All(x => x.ReferenceCode != pair.Key))
            .Select(pair => new ReferenceEntry
            {
                ReferenceCode = pair.Key, DisplayName = pair.Value.Name,
                Department = pair.Value.Department, CreatedAtUtc = clock.UtcNow
            }).ToArray();
        if (missing.Length > 0) await data.AddReferencesAsync(missing, ct);
        return missing.Length;
    }

    public async Task CleanupAsync(CancellationToken ct)
    {
        await using var exclusive = await gate.EnterAsync(ct);
        var uploaded = await data.UploadedBatchesAsync(ct);
        foreach (var batch in uploaded)
        {
            if (!IsExpired(batch) && files.Exists(batch.StorageKey)) continue;
            files.Delete(batch.StorageKey);
            batch.Status = BatchStatus.Expired;
            batch.FailureCode = "TemporaryFileExpired";
            await data.MarkExpiredAsync(batch, ct);
        }
    }

    private bool IsExpired(ImportBatch batch) => batch.CreatedAtUtc.AddHours(1) <= clock.UtcNow;

    private async Task<ImportBatch> RequireBatchAsync(Guid id, CancellationToken ct) =>
        await data.FindBatchAsync(id, ct) ?? throw new KeyNotFoundException("الدفعة غير موجودة.");

    private static string SanitizeFileName(string fileName)
    {
        var onlyName = fileName.Replace('\\', '/').Split('/').LastOrDefault() ?? "";
        var filtered = new string(onlyName.Where(c => !char.IsControl(c) && c is not '<' and not '>' and not ':' and not '"' and not '|' and not '?' and not '*').ToArray()).Trim();
        return filtered.Length == 0 ? "synthetic.xlsx" : filtered.Length > 150 ? filtered[^150..] : filtered;
    }
}
