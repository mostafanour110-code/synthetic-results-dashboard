using Microsoft.AspNetCore.Http.Features;
using Microsoft.EntityFrameworkCore;
using SyntheticResultsDashboard.Application.Contracts;
using SyntheticResultsDashboard.Application.Services;
using SyntheticResultsDashboard.Infrastructure.Persistence;
using SyntheticResultsDashboard.Infrastructure.Services;
using SyntheticResultsDashboard.Infrastructure.Storage;
using SyntheticResultsDashboard.Infrastructure.Workbooks;

var builder = WebApplication.CreateBuilder(args);

// This unauthenticated teaching sample is ALWAYS loopback-only (single process).
builder.WebHost.UseUrls("http://127.0.0.1:5087");
builder.WebHost.ConfigureKestrel(options => options.Limits.MaxRequestBodySize = 3 * 1024 * 1024);
builder.Services.Configure<FormOptions>(options => options.MultipartBodyLengthLimit = 3 * 1024 * 1024);
builder.Services.AddRazorPages();
var appDataDir = Path.Combine(builder.Environment.ContentRootPath, "App_Data");
Directory.CreateDirectory(appDataDir);
// Store only redacted technical event metadata locally, never exception messages.
builder.Logging.ClearProviders();
builder.Logging.AddProvider(new LocalRedactedLoggerProvider(Path.Combine(appDataDir, "logs", "events.log")));
builder.Services.AddDbContext<ResultsDbContext>(o => o.UseSqlite($"Data Source={Path.Combine(appDataDir, "synthetic.db")}"));
builder.Services.AddScoped<IAppData, SqliteAppData>();
builder.Services.AddScoped<ResultsService>();
builder.Services.AddSingleton<IExecutionGate, SingleProcessGate>();
builder.Services.AddSingleton<IClock, SystemClock>();
builder.Services.AddSingleton<IWorkbookReader, SecureWorkbookReader>();
builder.Services.AddSingleton<IReportWriter, ClosedXmlReportWriter>();
builder.Services.AddSingleton<ITemporaryFileStore>(_ => new LocalTemporaryFileStore(builder.Environment.ContentRootPath));

var app = builder.Build();
using (var scope = app.Services.CreateScope())
    scope.ServiceProvider.GetRequiredService<ResultsDbContext>().Database.Migrate();

app.UseExceptionHandler("/Error");
app.UseStaticFiles();
app.UseRouting();
app.Use(async (context, next) =>
{
    // Cleanup is synchronized with analysis. No background worker or multi-instance support.
    using var scope = context.RequestServices.CreateScope();
    await scope.ServiceProvider.GetRequiredService<ResultsService>().CleanupAsync(context.RequestAborted);
    await next();
});
app.MapRazorPages();
app.Run();

public partial class Program { } // WebApplicationFactory integration tests.
