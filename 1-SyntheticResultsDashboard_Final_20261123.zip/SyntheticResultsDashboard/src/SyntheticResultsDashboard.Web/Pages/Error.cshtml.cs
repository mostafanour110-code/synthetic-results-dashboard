using System.Diagnostics;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SyntheticResultsDashboard.Web.Pages;

public sealed class ErrorModel : PageModel
{
    public string TraceId { get; private set; } = "";
    public void OnGet()
    {
        Response.StatusCode = 500;
        TraceId = Activity.Current?.Id ?? HttpContext.TraceIdentifier;
    }
}
