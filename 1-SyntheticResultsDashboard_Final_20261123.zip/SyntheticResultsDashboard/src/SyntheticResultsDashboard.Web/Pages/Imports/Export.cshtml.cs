using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SyntheticResultsDashboard.Application.Contracts;
using SyntheticResultsDashboard.Application.Services;

namespace SyntheticResultsDashboard.Web.Pages.Imports;

public sealed class ExportModel(ResultsService service) : PageModel
{
    public async Task<IActionResult> OnGetAsync(Guid id, CancellationToken ct)
    {
        try
        {
            var output = await service.ExportAsync(id, ct);
            return File(output.Data, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", output.FileName);
        }
        catch (KeyNotFoundException) { return NotFound(); }
        catch (PublicValidationException ex) { return StatusCode(StatusCodes.Status409Conflict, ex.Message); }
    }
}
