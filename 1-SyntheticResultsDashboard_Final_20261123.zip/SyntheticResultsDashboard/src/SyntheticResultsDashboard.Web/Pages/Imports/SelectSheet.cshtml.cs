using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SyntheticResultsDashboard.Application.Contracts;
using SyntheticResultsDashboard.Application.Services;
using SyntheticResultsDashboard.Domain.Entities;

namespace SyntheticResultsDashboard.Web.Pages.Imports;

public sealed class SelectSheetModel(ResultsService service) : PageModel
{
    public ImportBatch? Batch { get; private set; }
    public IReadOnlyList<string> Sheets { get; private set; } = [];
    [BindProperty] public string SelectedSheetName { get; set; } = "";

    public async Task<IActionResult> OnGetAsync(Guid id, CancellationToken ct)
    {
        try { await LoadAsync(id, ct); return Page(); }
        catch (KeyNotFoundException) { return NotFound(); }
        catch (PublicValidationException ex) { return StatusCode(StatusCodes.Status409Conflict, ex.Message); }
    }

    public async Task<IActionResult> OnPostAsync(Guid id, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(SelectedSheetName))
            ModelState.AddModelError(nameof(SelectedSheetName), "اختار ورقة مرئية من القائمة.");
        if (!ModelState.IsValid)
        {
            try { await LoadAsync(id, ct); return Page(); }
            catch (KeyNotFoundException) { return NotFound(); }
            catch (PublicValidationException ex) { return StatusCode(StatusCodes.Status409Conflict, ex.Message); }
        }
        try
        {
            await service.AnalyzeAsync(id, SelectedSheetName, ct);
            return RedirectToPage("/Imports/Details", new { id });
        }
        catch (KeyNotFoundException) { return NotFound(); }
        catch (PublicValidationException ex)
        {
            ModelState.AddModelError(nameof(SelectedSheetName), ex.Message);
            try { await LoadAsync(id, ct); return Page(); }
            catch (PublicValidationException) { return StatusCode(StatusCodes.Status409Conflict, ex.Message); }
        }
    }

    private async Task LoadAsync(Guid id, CancellationToken ct)
    {
        Batch = await service.GetBatchAsync(id, ct) ?? throw new KeyNotFoundException();
        Sheets = await service.GetSheetsAsync(id, ct);
    }
}
