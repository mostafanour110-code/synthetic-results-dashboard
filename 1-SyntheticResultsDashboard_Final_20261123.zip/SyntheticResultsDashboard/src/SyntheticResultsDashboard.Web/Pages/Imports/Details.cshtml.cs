using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SyntheticResultsDashboard.Application.Contracts;
using SyntheticResultsDashboard.Application.Models;
using SyntheticResultsDashboard.Application.Services;
using SyntheticResultsDashboard.Domain.Entities;

namespace SyntheticResultsDashboard.Web.Pages.Imports;

public sealed class DetailsModel(ResultsService service) : PageModel
{
    public ImportBatch? Batch { get; private set; }
    public RowPage? Results { get; private set; }
    public string? OutcomeFilter { get; private set; }

    public async Task<IActionResult> OnGetAsync(Guid id, string? outcome, int pageNumber = 1, CancellationToken ct = default)
    {
        if (!ModelState.IsValid || pageNumber < 1 || pageNumber > 100_000)
            return BadRequest("قيمة الصفحة غير صحيحة.");
        RowOutcome? filter = null;
        if (!string.IsNullOrEmpty(outcome))
        {
            if (!Enum.TryParse<RowOutcome>(outcome, ignoreCase: false, out var parsed) ||
                !Enum.IsDefined(parsed))
                return BadRequest("قيمة فلتر الحالة غير صحيحة.");
            filter = parsed;
        }
        try
        {
            Batch = await service.GetBatchAsync(id, ct) ?? throw new KeyNotFoundException();
            Results = await service.GetPageAsync(id, filter, pageNumber, ct);
            OutcomeFilter = outcome;
            return Page();
        }
        catch (KeyNotFoundException) { return NotFound(); }
        catch (PublicValidationException ex) { return StatusCode(StatusCodes.Status409Conflict, ex.Message); }
    }
}
