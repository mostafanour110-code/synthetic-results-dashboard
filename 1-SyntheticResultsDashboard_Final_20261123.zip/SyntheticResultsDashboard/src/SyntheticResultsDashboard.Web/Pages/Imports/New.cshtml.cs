using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SyntheticResultsDashboard.Application.Contracts;
using SyntheticResultsDashboard.Application.Services;

namespace SyntheticResultsDashboard.Web.Pages.Imports;

public sealed class NewModel(ResultsService service) : PageModel
{
    [BindProperty] public IFormFile? Workbook { get; set; }

    public async Task<IActionResult> OnPostAsync(CancellationToken ct)
    {
        if (Workbook is null)
        {
            ModelState.AddModelError(nameof(Workbook), "اختار ملف XLSX أولًا.");
            return Page();
        }
        try
        {
            using var input = Workbook.OpenReadStream();
            var batchId = await service.UploadAsync(input, Workbook.FileName, Workbook.Length, ct);
            return RedirectToPage("/Imports/SelectSheet", new { id = batchId });
        }
        catch (PublicValidationException ex)
        {
            ModelState.AddModelError(nameof(Workbook), ex.Message);
            return Page();
        }
    }
}
