using Microsoft.AspNetCore.Mvc.RazorPages;
using SyntheticResultsDashboard.Application.Services;
using SyntheticResultsDashboard.Domain.Entities;

namespace SyntheticResultsDashboard.Web.Pages;

public sealed class IndexModel(ResultsService results) : PageModel
{
    public ImportBatch? Latest { get; private set; }
    public async Task OnGetAsync(CancellationToken ct) => Latest = await results.GetLatestAsync(ct);
}
