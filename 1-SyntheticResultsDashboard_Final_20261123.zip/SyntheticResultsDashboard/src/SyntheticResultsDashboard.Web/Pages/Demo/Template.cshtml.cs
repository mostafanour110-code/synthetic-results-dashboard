using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SyntheticResultsDashboard.Application.Services;

namespace SyntheticResultsDashboard.Web.Pages.Demo;

public sealed class TemplateModel(ResultsService service) : PageModel
{
    public IActionResult OnGet() => File(service.Template(),
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "synthetic-demo-template.xlsx");
}
