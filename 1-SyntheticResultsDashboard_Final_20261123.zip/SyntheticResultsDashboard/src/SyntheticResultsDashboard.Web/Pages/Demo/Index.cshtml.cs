using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SyntheticResultsDashboard.Application.Contracts;
using SyntheticResultsDashboard.Application.Services;

namespace SyntheticResultsDashboard.Web.Pages.Demo;

public sealed class IndexModel(ResultsService service) : PageModel
{
    [TempData] public string? Message { get; set; }

    public async Task<IActionResult> OnPostAsync(CancellationToken ct)
    {
        try
        {
            int added = await service.SeedDemoAsync(ct);
            Message = added == 0 ? "الأربعة سجلات التجريبية موجودة بالفعل، بدون تكرار." : $"أضيف {added} سجل مرجعي تجريبي.";
        }
        catch (PublicValidationException ex) { ModelState.AddModelError("", ex.Message); return Page(); }
        return RedirectToPage();
    }
}
