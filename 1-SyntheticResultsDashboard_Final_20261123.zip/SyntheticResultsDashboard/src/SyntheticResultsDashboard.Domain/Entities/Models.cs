namespace SyntheticResultsDashboard.Domain.Entities;

public enum BatchStatus { Uploaded, Completed, Expired, Failed }
public enum RowOutcome { Invalid, NotFound, DepartmentMismatch, Matched }
public enum CellKind { Empty, Text, Number, Date, Boolean, Other }

public sealed class ReferenceEntry
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string ReferenceCode { get; set; } = "";
    public string DisplayName { get; set; } = "";
    public string Department { get; set; } = "";
    public DateTimeOffset CreatedAtUtc { get; set; }
}

public sealed class ImportBatch
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string OriginalFileName { get; set; } = "";
    public string StorageKey { get; set; } = "";
    public long FileSizeBytes { get; set; }
    public BatchStatus Status { get; set; } = BatchStatus.Uploaded;
    public string? SelectedSheetName { get; set; }
    public DateTimeOffset CreatedAtUtc { get; set; }
    public DateTimeOffset? CompletedAtUtc { get; set; }
    public int TotalRows { get; set; }
    public int MatchedCount { get; set; }
    public int InvalidCount { get; set; }
    public int NotFoundCount { get; set; }
    public int DepartmentMismatchCount { get; set; }
    public string? FailureCode { get; set; }
    public List<ImportRow> Rows { get; set; } = [];
}

public sealed class ImportRow
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public Guid BatchId { get; set; }
    public ImportBatch? Batch { get; set; }
    public int SheetRowNumber { get; set; }
    public string ReferenceCode { get; set; } = "";
    public string DisplayName { get; set; } = "";
    public string Department { get; set; } = "";
    public decimal? Score { get; set; }
    public RowOutcome Outcome { get; set; }
    // Stored error codes are machine-generated from a fixed list, never SQL or arbitrary input.
    public string ErrorCodes { get; set; } = "";
    public Guid? MatchedReferenceId { get; set; }
}

public sealed record WorkbookCell(CellKind Kind, string Text, decimal? Number = null)
{
    public static WorkbookCell Empty() => new(CellKind.Empty, "");
    public static WorkbookCell TextValue(string text) => new(CellKind.Text, text);
    public static WorkbookCell NumberValue(decimal number) => new(CellKind.Number, "", number);
}

public sealed record WorkbookRecord(int SheetRowNumber, WorkbookCell Code, WorkbookCell Name,
    WorkbookCell Department, WorkbookCell Score)
{
    public bool IsBlank => new[] { Code, Name, Department, Score }
        .All(x => x.Kind == CellKind.Empty || (x.Kind == CellKind.Text && string.IsNullOrEmpty(x.Text)));
}

public sealed record ValidatedRecord(int SheetRowNumber, string ReferenceCode, string DisplayName,
    string Department, decimal? Score, IReadOnlyList<string> Errors)
{
    public bool IsValid => Errors.Count == 0;
}
