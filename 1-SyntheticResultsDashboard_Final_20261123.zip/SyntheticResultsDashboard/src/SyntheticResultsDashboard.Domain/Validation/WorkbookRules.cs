using System.Text.RegularExpressions;
using SyntheticResultsDashboard.Domain.Entities;

namespace SyntheticResultsDashboard.Domain.Validation;

public static partial class WorkbookRules
{
    [GeneratedRegex("^[A-Z0-9][A-Z0-9-]{0,29}$", RegexOptions.CultureInvariant)]
    private static partial Regex CodePattern();

    public static IReadOnlyList<ValidatedRecord> Validate(IReadOnlyList<WorkbookRecord> rows)
    {
        var duplicateCodes = rows
            .Where(x => x.Code.Kind == CellKind.Text)
            .Select(x => x.Code.Text.Trim())
            .Where(x => x.Length != 0)
            .GroupBy(x => x, StringComparer.Ordinal)
            .Where(g => g.Count() > 1)
            .Select(g => g.Key)
            .ToHashSet(StringComparer.Ordinal);

        return rows.Select(row => ValidateOne(row, duplicateCodes)).ToArray();
    }

    private static ValidatedRecord ValidateOne(WorkbookRecord row, HashSet<string> duplicateCodes)
    {
        var errors = new List<string>();
        var code = row.Code.Text.Trim();
        var name = row.Name.Text.Trim();
        var department = row.Department.Text.Trim();
        var score = row.Score.Number;
        if (row.Code.Kind != CellKind.Text || !CodePattern().IsMatch(code))
            errors.Add("InvalidReferenceCode");
        if (row.Name.Kind != CellKind.Text || name.Length is < 1 or > 100)
            errors.Add("InvalidDisplayName");
        if (row.Department.Kind != CellKind.Text || (department != "SCI" && department != "ART"))
            errors.Add("InvalidDepartment");
        if (row.Score.Kind != CellKind.Number || score is null)
            errors.Add("InvalidScoreType");
        else if (score < 0 || score > 100)
            errors.Add("ScoreOutOfRange");
        else if (decimal.Round(score.Value, 2) != score.Value)
            errors.Add("ScorePrecisionExceeded");
        if (duplicateCodes.Contains(code))
            errors.Add("DuplicateReferenceCode");
        // Never retain unbounded values from an untrusted workbook in SQLite or exports.
        return new(row.SheetRowNumber, Limit(code, 30), Limit(name, 100), Limit(department, 20),
            row.Score.Kind == CellKind.Number ? score : null, errors);
    }

    private static string Limit(string text, int max) => text.Length <= max ? text : text[..max];

    public static RowOutcome Match(ValidatedRecord record, ReferenceEntry? reference)
    {
        if (!record.IsValid) return RowOutcome.Invalid;
        if (reference is null) return RowOutcome.NotFound;
        return string.Equals(record.Department, reference.Department, StringComparison.Ordinal)
            ? RowOutcome.Matched : RowOutcome.DepartmentMismatch;
    }
}
