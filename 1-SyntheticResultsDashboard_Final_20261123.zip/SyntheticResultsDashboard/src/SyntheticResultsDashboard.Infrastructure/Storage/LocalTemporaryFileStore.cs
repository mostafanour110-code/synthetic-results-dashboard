using System.Text.RegularExpressions;
using SyntheticResultsDashboard.Application.Contracts;

namespace SyntheticResultsDashboard.Infrastructure.Storage;

public sealed class LocalTemporaryFileStore : ITemporaryFileStore
{
    private const int MaxFileBytes = 2 * 1024 * 1024;
    private readonly string _directory;

    public LocalTemporaryFileStore(string root)
    {
        _directory = Path.GetFullPath(Path.Combine(root, "App_Data", "StagedWorkbooks"));
        Directory.CreateDirectory(_directory);
    }

    public async Task<(string StorageKey, long Length)> SaveAsync(Stream input, CancellationToken ct)
    {
        var key = Guid.NewGuid().ToString("N");
        var path = Resolve(key);
        try
        {
            await using var file = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.None,
                81920, FileOptions.Asynchronous | FileOptions.SequentialScan);
            var buffer = new byte[81920];
            int n;
            long bytes = 0;
            while ((n = await input.ReadAsync(buffer, ct)) > 0)
            {
                bytes += n;
                if (bytes > MaxFileBytes)
                    throw new PublicValidationException("حجم الملف الفعلي يتجاوز 2 ميجابايت.");
                await file.WriteAsync(buffer.AsMemory(0, n), ct);
            }
            if (bytes == 0) throw new PublicValidationException("الملف فارغ.");
            return (key, bytes);
        }
        catch { Delete(key); throw; }
    }

    public string Resolve(string key)
    {
        if (key.Length != 32 || !Regex.IsMatch(key, "^[0-9a-f]{32}$", RegexOptions.CultureInvariant))
            throw new PublicValidationException("معرف التخزين المؤقت غير صالح.");
        return Path.Combine(_directory, key + ".tmp");
    }

    public bool Exists(string key) => File.Exists(Resolve(key));

    public void Delete(string key)
    {
        var path = Resolve(key);
        if (File.Exists(path)) File.Delete(path);
    }
}
