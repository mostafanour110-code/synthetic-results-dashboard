using System.Diagnostics;
using Microsoft.Extensions.Logging;

namespace SyntheticResultsDashboard.Infrastructure.Services;

// Intentionally never writes exception messages, stack traces, workbook values, or request paths.
public sealed class LocalRedactedLoggerProvider : ILoggerProvider
{
    private readonly string _path;
    private readonly object _sync = new();

    public LocalRedactedLoggerProvider(string path)
    {
        _path = path;
        Directory.CreateDirectory(Path.GetDirectoryName(_path)!);
    }

    public ILogger CreateLogger(string categoryName) => new SafeLogger(this, categoryName);
    public void Dispose() { }

    private sealed class SafeLogger(LocalRedactedLoggerProvider provider, string category) : ILogger
    {
        public IDisposable? BeginScope<TState>(TState state) where TState : notnull => NoopScope.Instance;
        public bool IsEnabled(LogLevel logLevel) => logLevel >= LogLevel.Warning && logLevel != LogLevel.None;
        public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception? exception,
            Func<TState, Exception?, string> formatter)
        {
            if (!IsEnabled(logLevel)) return;
            var trace = Activity.Current?.Id ?? "none";
            var cleanCategory = new string(category.Where(c => char.IsLetterOrDigit(c) || c is '.' or '_').Take(120).ToArray());
            var line = $"{DateTimeOffset.UtcNow:O} | {logLevel} | {cleanCategory} | event={eventId.Id} | trace={trace} | exception={exception?.GetType().Name ?? "none"}\n";
            lock (provider._sync) File.AppendAllText(provider._path, line);
        }
    }

    private sealed class NoopScope : IDisposable
    {
        public static NoopScope Instance { get; } = new();
        public void Dispose() { }
    }
}
