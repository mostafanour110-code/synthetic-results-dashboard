using SyntheticResultsDashboard.Application.Contracts;

namespace SyntheticResultsDashboard.Infrastructure.Services;

public sealed class SystemClock : IClock { public DateTimeOffset UtcNow => DateTimeOffset.UtcNow; }

public sealed class SingleProcessGate : IExecutionGate
{
    private readonly SemaphoreSlim _mutex = new(1, 1);

    public async Task<IAsyncDisposable> EnterAsync(CancellationToken cancellationToken)
    {
        await _mutex.WaitAsync(cancellationToken);
        return new Releaser(_mutex);
    }

    private sealed class Releaser(SemaphoreSlim mutex) : IAsyncDisposable
    {
        public ValueTask DisposeAsync() { mutex.Release(); return ValueTask.CompletedTask; }
    }
}
