using ClosedXML.Excel;
using SyntheticResultsDashboard.Application.Contracts;
using SyntheticResultsDashboard.Domain.Entities;

namespace SyntheticResultsDashboard.Infrastructure.Workbooks;

public sealed class ClosedXmlReportWriter : IReportWriter
{
    public byte[] WriteReport(ImportBatch batch, IReadOnlyList<ImportRow> rows)
    {
        using var book = new XLWorkbook();
        var summary = book.AddWorksheet("Summary");
        string[,] values =
        {
            { "Field", "Value" },
            { "Batch ID", batch.Id.ToString("D") },
            { "Completed (UTC)", batch.CompletedAtUtc?.ToUniversalTime().ToString("O") ?? "" },
            { "Selected Sheet", batch.SelectedSheetName ?? "" },
            { "TotalRows", batch.TotalRows.ToString() },
            { "Matched", batch.MatchedCount.ToString() },
            { "NotFound", batch.NotFoundCount.ToString() },
            { "DepartmentMismatch", batch.DepartmentMismatchCount.ToString() },
            { "Invalid", batch.InvalidCount.ToString() },
            { "Notice", "نموذج تجريبي، بيانات مصطنعة فقط" },
            { "Matching", "Matched = تطابق الرمز والقسم فقط؛ لا يعني صحة هوية أو نتيجة أكاديمية." },
            { "Export Scope", "كل صفوف الدفعة، بصرف النظر عن فلتر أو صفحة العرض." },
            { "Outcomes", "Matched: مطابق / NotFound: غير موجود / DepartmentMismatch: اختلاف القسم / Invalid: غير صالح" }
        };
        for (int r = 0; r < values.GetLength(0); r++)
        for (int c = 0; c < 2; c++) SetText(summary.Cell(r + 1, c + 1), values[r, c]);
        StyleHeader(summary.Range("A1:B1"));
        summary.Column(1).Width = 24;
        summary.Column(2).Width = 88;
        summary.Column(2).Style.Alignment.WrapText = true;
        summary.SheetView.FreezeRows(1);

        var sheet = book.AddWorksheet("Rows");
        string[] headers = ["SheetRowNumber", "ReferenceCode", "DisplayName", "Department", "Score", "Outcome", "ErrorCodes"];
        for (int c = 0; c < headers.Length; c++) SetText(sheet.Cell(1, c + 1), headers[c]);
        int i = 2;
        foreach (var row in rows.OrderBy(x => x.SheetRowNumber))
        {
            sheet.Cell(i, 1).SetValue(row.SheetRowNumber);
            SetText(sheet.Cell(i, 2), row.ReferenceCode);
            SetText(sheet.Cell(i, 3), row.DisplayName);
            SetText(sheet.Cell(i, 4), row.Department);
            if (row.Score.HasValue) sheet.Cell(i, 5).SetValue(row.Score.Value);
            SetText(sheet.Cell(i, 6), row.Outcome.ToString());
            SetText(sheet.Cell(i, 7), row.ErrorCodes);
            i++;
        }
        StyleHeader(sheet.Range("A1:G1"));
        sheet.Column(1).Width = 20; sheet.Column(2).Width = 23;
        sheet.Column(3).Width = 32; sheet.Column(4).Width = 17;
        sheet.Column(5).Width = 15; sheet.Column(6).Width = 26;
        sheet.Column(7).Width = 48;
        sheet.SheetView.FreezeRows(1);
        sheet.Range(1, 1, Math.Max(2, i - 1), 7).SetAutoFilter();
        return ToBytes(book);
    }

    public byte[] WriteDemoTemplate()
    {
        using var book = new XLWorkbook();
        var sheet = book.AddWorksheet("DemoResults");
        string[,] table =
        {
            { "ReferenceCode", "DisplayName", "Department", "Score" },
            { "DEMO-001", "اسم تجريبي 1", "SCI", "75.50" },
            { "DEMO-002", "اسم تجريبي 2", "SCI", "60" },
            { "DEMO-999", "اسم تجريبي 3", "ART", "80" },
            { "DEMO-003", "اسم تجريبي 4", "SCI", "101" },
            { "DEMO-004", "اسم تجريبي 5", "ART", "50" },
            { "DEMO-004", "اسم تجريبي 6", "ART", "55" }
        };
        for (var r = 0; r < table.GetLength(0); r++)
        for (var c = 0; c < table.GetLength(1); c++)
        {
            var cell = sheet.Cell(r + 1, c + 1);
            if (c == 3 && r > 0)
                cell.SetValue(decimal.Parse(table[r, c], System.Globalization.CultureInfo.InvariantCulture));
            else SetText(cell, table[r, c]);
        }
        sheet.Cell(2, 4).Style.NumberFormat.Format = "0.00";
        StyleHeader(sheet.Range("A1:D1"));
        sheet.Column(1).Width = 24; sheet.Column(2).Width = 28;
        sheet.Column(3).Width = 18; sheet.Column(4).Width = 15;
        sheet.SheetView.FreezeRows(1);
        var hidden = book.AddWorksheet("HiddenDemo");
        SetText(hidden.Cell(1, 1), "مصطنع للاختبار فقط");
        hidden.Visibility = XLWorksheetVisibility.Hidden;
        return ToBytes(book);
    }

    private static void SetText(IXLCell cell, string text)
    {
        cell.Style.NumberFormat.Format = "@";
        // Zero-width prefix disarms Excel formula injection without changing visible text.
        if (text.Length > 0 && text[0] is '=' or '+' or '-' or '@' or '\t' or '\r')
            text = "\u200B" + text;
        cell.SetValue(text);
    }

    private static void StyleHeader(IXLRange range)
    {
        range.Style.Fill.BackgroundColor = XLColor.FromHtml("#194A76");
        range.Style.Font.FontColor = XLColor.White;
        range.Style.Font.Bold = true;
        range.Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;
        range.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
        range.Style.Alignment.WrapText = true;
        range.Style.Border.BottomBorder = XLBorderStyleValues.Thin;
        range.Style.Border.BottomBorderColor = XLColor.FromHtml("#B6C7D8");
    }

    private static byte[] ToBytes(XLWorkbook book)
    {
        using var buffer = new MemoryStream();
        book.SaveAs(buffer);
        return buffer.ToArray();
    }
}
