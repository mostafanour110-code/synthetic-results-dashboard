using System.Globalization;
using System.IO.Compression;
using System.Xml;
using ClosedXML.Excel;
using SyntheticResultsDashboard.Application.Contracts;
using SyntheticResultsDashboard.Domain.Entities;

namespace SyntheticResultsDashboard.Infrastructure.Workbooks;

public sealed class SecureWorkbookReader : IWorkbookReader
{
    private static readonly string[] Headers = ["ReferenceCode", "DisplayName", "Department", "Score"];
    private const long MaxCompressed = 2L * 1024 * 1024;
    private const long MaxExpanded = 20L * 1024 * 1024;

    public IReadOnlyList<string> InspectAndListVisibleSheets(string fullPath)
    {
        Preflight(fullPath);
        try
        {
            using var input = File.OpenRead(fullPath);
            using var workbook = new XLWorkbook(input);
            var all = workbook.Worksheets.ToArray();
            if (all.Length is < 1 or > 10)
                throw new PublicValidationException("عدد أوراق المصنف يجب ألا يتجاوز 10.");
            var visible = all.Where(x => x.Visibility == XLWorksheetVisibility.Visible)
                .Select(x => x.Name).ToArray();
            if (visible.Length == 0)
                throw new PublicValidationException("لا توجد أوراق ظاهرة داخل المصنف.");
            if (visible.Any(name => name.Length > 100))
                throw new PublicValidationException("اسم إحدى الأوراق يتجاوز الحد المسموح.");
            return visible;
        }
        catch (PublicValidationException) { throw; }
        catch (Exception ex) when (ex is IOException or InvalidDataException or ArgumentException or NotSupportedException or FormatException or XmlException)
        {
            throw new PublicValidationException("ملف XLSX غير سليم أو يحتوي على خصائص غير مدعومة.");
        }
    }

    public IReadOnlyList<WorkbookRecord> ReadSheet(string fullPath, string sheetName)
    {
        var allowed = InspectAndListVisibleSheets(fullPath);
        if (!allowed.Contains(sheetName, StringComparer.Ordinal))
            throw new PublicValidationException("اسم الورقة غير مسموح.");
        try
        {
            using var input = File.OpenRead(fullPath);
            using var workbook = new XLWorkbook(input);
            var sheet = workbook.Worksheet(sheetName);
            var lastRow = sheet.LastRowUsed(XLCellsUsedOptions.All)?.RowNumber() ?? 0;
            var lastCol = sheet.LastColumnUsed(XLCellsUsedOptions.All)?.ColumnNumber() ?? 0;
            if (lastRow > 2001 || lastCol > 4)
                throw new PublicValidationException("مساحة الورقة تتجاوز الحد: صف 2001 وعمود D.");
            if (lastRow < 1 || lastCol != 4)
                throw new PublicValidationException("الورقة يجب أن تحتوي على الأعمدة الأربعة المطلوبة.");
            if (sheet.CellsUsed(XLCellsUsedOptions.AllContents).Any(x => x.HasFormula))
                throw new PublicValidationException("لا يُسمح بوجود صيغ Excel في الورقة المختارة.");
            if (sheet.MergedRanges.Any(range => range.RangeAddress.FirstAddress.RowNumber <= lastRow &&
                range.RangeAddress.FirstAddress.ColumnNumber <= 4))
                throw new PublicValidationException("الورقة تحتوي خلايا مدمجة مؤثرة في الجدول.");

            for (int c = 1; c <= 4; c++)
            {
                var cell = sheet.Cell(1, c);
                if (cell.DataType != XLDataType.Text || cell.GetString().Trim() != Headers[c - 1])
                    throw new PublicValidationException("عناوين الأعمدة غير مطابقة للعقد المطلوب أو ترتيبها غير صحيح.");
            }

            var rows = new List<WorkbookRecord>();
            for (int r = 2; r <= lastRow; r++)
            {
                var record = new WorkbookRecord(r, GetCell(sheet.Cell(r, 1)), GetCell(sheet.Cell(r, 2)),
                    GetCell(sheet.Cell(r, 3)), GetCell(sheet.Cell(r, 4)));
                if (record.IsBlank) continue;
                rows.Add(record);
                if (rows.Count > 1000)
                    throw new PublicValidationException("يُسمح بحد أقصى 1000 صف بيانات غير فارغ.");
            }
            return rows;
        }
        catch (PublicValidationException) { throw; }
        catch (Exception ex) when (ex is IOException or InvalidDataException or ArgumentException or NotSupportedException or FormatException or OverflowException)
        {
            throw new PublicValidationException("تعذر قراءة الورقة بشكل آمن. راجع تنسيق XLSX.");
        }
    }

    private static WorkbookCell GetCell(IXLCell cell) => cell.DataType switch
    {
        XLDataType.Blank => WorkbookCell.Empty(),
        XLDataType.Text => string.IsNullOrEmpty(cell.GetString()) ? WorkbookCell.Empty() : WorkbookCell.TextValue(cell.GetString()),
        XLDataType.Number => ReadNumber(cell),
        XLDataType.DateTime => new(CellKind.Date, ""),
        XLDataType.Boolean => new(CellKind.Boolean, ""),
        _ => new(CellKind.Other, "")
    };

    private static WorkbookCell ReadNumber(IXLCell cell)
    {
        try { return WorkbookCell.NumberValue(Convert.ToDecimal(cell.GetDouble(), CultureInfo.InvariantCulture)); }
        catch (Exception ex) when (ex is OverflowException or FormatException)
        { return new WorkbookCell(CellKind.Other, ""); }
    }

    private static void Preflight(string fullPath)
    {
        try
        {
            var info = new FileInfo(fullPath);
            if (!info.Exists || info.Length is <= 0 or > MaxCompressed)
                throw new PublicValidationException("حجم الملف المضغوط غير مسموح.");
            using var raw = File.OpenRead(fullPath);
            Span<byte> signature = stackalloc byte[4];
            if (raw.Read(signature) != 4 || !signature.SequenceEqual(new byte[] { 0x50, 0x4B, 0x03, 0x04 }))
                throw new PublicValidationException("محتوى الملف ليس مصنف XLSX صالحًا.");
            raw.Position = 0;
            using var zip = new ZipArchive(raw, ZipArchiveMode.Read, leaveOpen: false);
            if (zip.Entries.Count is < 1 or > 200)
                throw new PublicValidationException("عدد أجزاء XLSX غير مسموح.");
            if (zip.GetEntry("[Content_Types].xml") is null || zip.GetEntry("xl/workbook.xml") is null)
                throw new PublicValidationException("بنية ملف XLSX غير مكتملة.");
            long declared = 0;
            long actual = 0;
            byte[] buffer = new byte[16 * 1024];
            foreach (var entry in zip.Entries)
            {
                var name = entry.FullName;
                if (name.StartsWith('/') || name.Contains('\\') || name.Contains(':') ||
                    name.Split('/').Any(part => part is ".." or "."))
                    throw new PublicValidationException("يوجد مسار غير آمن داخل ملف XLSX.");
                string n = name.ToLowerInvariant();
                if (n.EndsWith("vbaproject.bin") || n.Contains("externallinks/") ||
                    n.Contains("/activex/") || n.Contains("/embeddings/") ||
                    n.Contains("/connections") || n.Contains("/querytables/") ||
                    n.Contains("/pivotcache/") || n.StartsWith("customxml/"))
                    throw new PublicValidationException("المصنف يحتوي مكونات أو روابط خارجية غير مسموحة.");
                declared = checked(declared + entry.Length);
                if (declared > MaxExpanded)
                    throw new PublicValidationException("المحتوى غير المضغوط يتجاوز 20 ميجابايت.");
                using var stream = entry.Open();
                int read;
                if (n.EndsWith(".rels") || n == "[content_types].xml")
                {
                    // Relationship and content-type files are tiny in a bounded workbook.
                    using var ms = new MemoryStream();
                    while ((read = stream.Read(buffer)) != 0)
                    {
                        actual += read;
                        if (actual > MaxExpanded) throw new PublicValidationException("محتوى مصنف مبالغ في حجمه.");
                        ms.Write(buffer, 0, read);
                    }
                    ms.Position = 0;
                    using var reader = XmlReader.Create(ms, new XmlReaderSettings
                    {
                        DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null,
                        MaxCharactersInDocument = 2L * 1024 * 1024
                    });
                    while (reader.Read())
                    {
                        if (reader.NodeType != XmlNodeType.Element) continue;
                        if (n.EndsWith(".rels") && reader.LocalName == "Relationship" &&
                            string.Equals(reader.GetAttribute("TargetMode"), "External", StringComparison.OrdinalIgnoreCase))
                            throw new PublicValidationException("علاقات خارجية غير مسموح بها داخل الملف.");
                        if (n == "[content_types].xml" && (reader.LocalName is "Override" or "Default") &&
                            (reader.GetAttribute("ContentType") ?? "").Contains("macro", StringComparison.OrdinalIgnoreCase))
                            throw new PublicValidationException("المصنف يحتوي عناصر ماكرو غير مسموحة.");
                    }
                }
                else
                {
                    while ((read = stream.Read(buffer)) != 0)
                    {
                        actual += read;
                        if (actual > MaxExpanded) throw new PublicValidationException("محتوى مصنف مبالغ في حجمه.");
                    }
                }
            }
        }
        catch (PublicValidationException) { throw; }
        catch (Exception ex) when (ex is IOException or InvalidDataException or ArgumentException or NotSupportedException or OverflowException or XmlException)
        {
            throw new PublicValidationException("تعذر التحقق من بنية ZIP/OOXML للملف.");
        }
    }
}
