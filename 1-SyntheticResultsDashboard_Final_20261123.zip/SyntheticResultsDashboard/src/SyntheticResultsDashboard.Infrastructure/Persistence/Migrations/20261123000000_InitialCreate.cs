using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;

namespace SyntheticResultsDashboard.Infrastructure.Persistence.Migrations;

[DbContext(typeof(ResultsDbContext))]
[Migration("20261123000000_InitialCreate")]
public sealed class InitialCreate : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.CreateTable(
            name: "ImportBatches",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "TEXT", nullable: false),
                OriginalFileName = table.Column<string>(type: "TEXT", maxLength: 150, nullable: false),
                StorageKey = table.Column<string>(type: "TEXT", maxLength: 64, nullable: false),
                FileSizeBytes = table.Column<long>(type: "INTEGER", nullable: false),
                Status = table.Column<string>(type: "TEXT", maxLength: 20, nullable: false),
                SelectedSheetName = table.Column<string>(type: "TEXT", maxLength: 100, nullable: true),
                CreatedAtUtc = table.Column<string>(type: "TEXT", maxLength: 40, nullable: false),
                CompletedAtUtc = table.Column<string>(type: "TEXT", maxLength: 40, nullable: true),
                TotalRows = table.Column<int>(type: "INTEGER", nullable: false),
                MatchedCount = table.Column<int>(type: "INTEGER", nullable: false),
                InvalidCount = table.Column<int>(type: "INTEGER", nullable: false),
                NotFoundCount = table.Column<int>(type: "INTEGER", nullable: false),
                DepartmentMismatchCount = table.Column<int>(type: "INTEGER", nullable: false),
                FailureCode = table.Column<string>(type: "TEXT", maxLength: 64, nullable: true)
            },
            constraints: table => table.PrimaryKey("PK_ImportBatches", x => x.Id));
        migrationBuilder.CreateTable(
            name: "ReferenceEntries",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "TEXT", nullable: false),
                ReferenceCode = table.Column<string>(type: "TEXT", maxLength: 30, nullable: false),
                DisplayName = table.Column<string>(type: "TEXT", maxLength: 100, nullable: false),
                Department = table.Column<string>(type: "TEXT", maxLength: 3, nullable: false),
                CreatedAtUtc = table.Column<string>(type: "TEXT", maxLength: 40, nullable: false)
            },
            constraints: table => table.PrimaryKey("PK_ReferenceEntries", x => x.Id));
        migrationBuilder.CreateTable(
            name: "ImportRows",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "TEXT", nullable: false),
                BatchId = table.Column<Guid>(type: "TEXT", nullable: false),
                SheetRowNumber = table.Column<int>(type: "INTEGER", nullable: false),
                ReferenceCode = table.Column<string>(type: "TEXT", maxLength: 30, nullable: false),
                DisplayName = table.Column<string>(type: "TEXT", maxLength: 100, nullable: false),
                Department = table.Column<string>(type: "TEXT", maxLength: 20, nullable: false),
                Score = table.Column<decimal>(type: "TEXT", nullable: true),
                Outcome = table.Column<string>(type: "TEXT", maxLength: 32, nullable: false),
                MatchedReferenceId = table.Column<Guid>(type: "TEXT", nullable: true),
                ErrorCodes = table.Column<string>(type: "TEXT", maxLength: 512, nullable: false)
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_ImportRows", x => x.Id);
                table.ForeignKey("FK_ImportRows_ImportBatches_BatchId", x => x.BatchId,
                    "ImportBatches", "Id", onDelete: ReferentialAction.Restrict);
            });
        migrationBuilder.CreateIndex(name: "IX_ReferenceEntries_ReferenceCode", table: "ReferenceEntries",
            column: "ReferenceCode", unique: true);
        migrationBuilder.CreateIndex(name: "IX_ImportRows_BatchId_SheetRowNumber", table: "ImportRows",
            columns: new[] { "BatchId", "SheetRowNumber" }, unique: true);
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropTable("ImportRows");
        migrationBuilder.DropTable("ReferenceEntries");
        migrationBuilder.DropTable("ImportBatches");
    }
}
