using System.Globalization;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using SyntheticResultsDashboard.Domain.Entities;

namespace SyntheticResultsDashboard.Infrastructure.Persistence.Migrations;

[DbContext(typeof(ResultsDbContext))]
public sealed class ResultsDbContextModelSnapshot : ModelSnapshot
{
    protected override void BuildModel(ModelBuilder modelBuilder)
    {
        modelBuilder.HasAnnotation("ProductVersion", "8.0.32");
        var utc = new ValueConverter<DateTimeOffset, string>(
            x => x.ToUniversalTime().ToString("O", CultureInfo.InvariantCulture),
            x => DateTimeOffset.Parse(x, CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal | DateTimeStyles.AdjustToUniversal));
        modelBuilder.Entity<ReferenceEntry>(b =>
        {
            b.ToTable("ReferenceEntries"); b.HasKey(x => x.Id);
            b.Property(x => x.ReferenceCode).HasMaxLength(30).IsRequired();
            b.Property(x => x.DisplayName).HasMaxLength(100).IsRequired();
            b.Property(x => x.Department).HasMaxLength(3).IsRequired();
            b.Property(x => x.CreatedAtUtc).HasConversion(utc).HasMaxLength(40).IsRequired();
            b.HasIndex(x => x.ReferenceCode).IsUnique();
        });
        modelBuilder.Entity<ImportBatch>(b =>
        {
            b.ToTable("ImportBatches"); b.HasKey(x => x.Id);
            b.Property(x => x.OriginalFileName).HasMaxLength(150).IsRequired();
            b.Property(x => x.StorageKey).HasMaxLength(64).IsRequired();
            b.Property(x => x.Status).HasConversion<string>().HasMaxLength(20);
            b.Property(x => x.SelectedSheetName).HasMaxLength(100);
            b.Property(x => x.CreatedAtUtc).HasConversion(utc).HasMaxLength(40);
            b.Property(x => x.CompletedAtUtc).HasConversion(utc).HasMaxLength(40);
            b.Property(x => x.FailureCode).HasMaxLength(64);
            b.HasMany(x => x.Rows).WithOne(x => x.Batch).HasForeignKey(x => x.BatchId).OnDelete(DeleteBehavior.Restrict);
        });
        modelBuilder.Entity<ImportRow>(b =>
        {
            b.ToTable("ImportRows"); b.HasKey(x => x.Id);
            b.Property(x => x.ReferenceCode).HasMaxLength(30).IsRequired();
            b.Property(x => x.DisplayName).HasMaxLength(100).IsRequired();
            b.Property(x => x.Department).HasMaxLength(20).IsRequired();
            b.Property(x => x.Outcome).HasConversion<string>().HasMaxLength(32);
            b.Property(x => x.ErrorCodes).HasMaxLength(512).IsRequired();
            b.HasIndex(x => new { x.BatchId, x.SheetRowNumber }).IsUnique();
        });
    }
}
