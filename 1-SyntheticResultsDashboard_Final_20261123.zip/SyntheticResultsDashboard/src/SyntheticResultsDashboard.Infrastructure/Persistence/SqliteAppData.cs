using Microsoft.EntityFrameworkCore;
using SyntheticResultsDashboard.Application.Contracts;
using SyntheticResultsDashboard.Domain.Entities;

namespace SyntheticResultsDashboard.Infrastructure.Persistence;

public sealed class SqliteAppData(ResultsDbContext db) : IAppData
{
    public Task<ImportBatch?> FindBatchAsync(Guid id, CancellationToken ct) =>
        db.ImportBatches.FirstOrDefaultAsync(x => x.Id == id, ct);

    public Task<ImportBatch?> LatestCompletedBatchAsync(CancellationToken ct) =>
        db.ImportBatches.AsNoTracking().Where(x => x.Status == BatchStatus.Completed)
            .OrderByDescending(x => x.CompletedAtUtc).FirstOrDefaultAsync(ct);

    public async Task AddBatchAsync(ImportBatch batch, CancellationToken ct)
    {
        db.ImportBatches.Add(batch);
        await db.SaveChangesAsync(ct);
    }

    public async Task<IReadOnlyDictionary<string, ReferenceEntry>> LookupReferencesAsync(IReadOnlyCollection<string> codes, CancellationToken ct)
    {
        if (codes.Count == 0) return new Dictionary<string, ReferenceEntry>();
        return await db.ReferenceEntries.AsNoTracking().Where(x => codes.Contains(x.ReferenceCode))
            .ToDictionaryAsync(x => x.ReferenceCode, StringComparer.Ordinal, ct);
    }

    public async Task<IReadOnlyList<ReferenceEntry>> AllDemoCodesAsync(CancellationToken ct) =>
        await db.ReferenceEntries.AsNoTracking().Where(x => x.ReferenceCode == "DEMO-001" || x.ReferenceCode == "DEMO-002" ||
            x.ReferenceCode == "DEMO-003" || x.ReferenceCode == "DEMO-004").ToListAsync(ct);

    public async Task AddReferencesAsync(IEnumerable<ReferenceEntry> references, CancellationToken ct)
    {
        db.ReferenceEntries.AddRange(references);
        await db.SaveChangesAsync(ct);
    }

    public async Task CompleteAsync(ImportBatch batch, IReadOnlyList<ImportRow> rows, CancellationToken ct)
    {
        // Summary, all rows and completed status become visible atomically.
        await using var tx = await db.Database.BeginTransactionAsync(ct);
        db.ImportRows.AddRange(rows);
        await db.SaveChangesAsync(ct);
        await tx.CommitAsync(ct);
    }

    public async Task MarkExpiredAsync(ImportBatch batch, CancellationToken ct) => await db.SaveChangesAsync(ct);

    public async Task<IReadOnlyList<ImportBatch>> UploadedBatchesAsync(CancellationToken ct) =>
        await db.ImportBatches.Where(x => x.Status == BatchStatus.Uploaded).ToListAsync(ct);

    public async Task<(int Count, IReadOnlyList<ImportRow> Rows)> PageRowsAsync(
        Guid batchId, RowOutcome? outcome, int page, int pageSize, CancellationToken ct)
    {
        var query = db.ImportRows.AsNoTracking().Where(x => x.BatchId == batchId);
        if (outcome.HasValue) query = query.Where(x => x.Outcome == outcome.Value);
        var count = await query.CountAsync(ct);
        var list = await query.OrderBy(x => x.SheetRowNumber)
            .Skip((page - 1) * pageSize).Take(pageSize).ToListAsync(ct);
        return (count, list);
    }

    public async Task<IReadOnlyList<ImportRow>> AllRowsAsync(Guid batchId, CancellationToken ct) =>
        await db.ImportRows.AsNoTracking().Where(x => x.BatchId == batchId)
            .OrderBy(x => x.SheetRowNumber).ToListAsync(ct);
}
