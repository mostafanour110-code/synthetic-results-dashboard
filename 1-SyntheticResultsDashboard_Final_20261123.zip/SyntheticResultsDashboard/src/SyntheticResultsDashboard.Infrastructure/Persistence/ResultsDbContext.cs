using System.Globalization;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using SyntheticResultsDashboard.Domain.Entities;

namespace SyntheticResultsDashboard.Infrastructure.Persistence;

public sealed class ResultsDbContext(DbContextOptions<ResultsDbContext> options) : DbContext(options)
{
    public DbSet<ReferenceEntry> ReferenceEntries => Set<ReferenceEntry>();
    public DbSet<ImportBatch> ImportBatches => Set<ImportBatch>();
    public DbSet<ImportRow> ImportRows => Set<ImportRow>();

    protected override void OnModelCreating(ModelBuilder builder)
    {
        var utcTime = new ValueConverter<DateTimeOffset, string>(
            x => x.ToUniversalTime().ToString("O", CultureInfo.InvariantCulture),
            x => DateTimeOffset.Parse(x, CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal | DateTimeStyles.AdjustToUniversal));
        builder.Entity<ReferenceEntry>(e =>
        {
            e.ToTable("ReferenceEntries");
            e.HasKey(x => x.Id);
            e.Property(x => x.ReferenceCode).HasMaxLength(30).IsRequired();
            e.HasIndex(x => x.ReferenceCode).IsUnique();
            e.Property(x => x.DisplayName).HasMaxLength(100).IsRequired();
            e.Property(x => x.Department).HasMaxLength(3).IsRequired();
            e.Property(x => x.CreatedAtUtc).HasConversion(utcTime).HasMaxLength(40).IsRequired();
        });
        builder.Entity<ImportBatch>(e =>
        {
            e.ToTable("ImportBatches");
            e.HasKey(x => x.Id);
            e.Property(x => x.OriginalFileName).HasMaxLength(150).IsRequired();
            e.Property(x => x.StorageKey).HasMaxLength(64).IsRequired();
            e.Property(x => x.Status).HasConversion<string>().HasMaxLength(20);
            e.Property(x => x.SelectedSheetName).HasMaxLength(100);
            e.Property(x => x.CreatedAtUtc).HasConversion(utcTime).HasMaxLength(40);
            e.Property(x => x.CompletedAtUtc).HasConversion(utcTime).HasMaxLength(40);
            e.Property(x => x.FailureCode).HasMaxLength(64);
            e.HasMany(x => x.Rows).WithOne(x => x.Batch).HasForeignKey(x => x.BatchId).OnDelete(DeleteBehavior.Restrict);
        });
        builder.Entity<ImportRow>(e =>
        {
            e.ToTable("ImportRows");
            e.HasKey(x => x.Id);
            e.HasIndex(x => new { x.BatchId, x.SheetRowNumber }).IsUnique();
            e.Property(x => x.ReferenceCode).HasMaxLength(30).IsRequired();
            e.Property(x => x.DisplayName).HasMaxLength(100).IsRequired();
            e.Property(x => x.Department).HasMaxLength(20).IsRequired();
            e.Property(x => x.Outcome).HasConversion<string>().HasMaxLength(32);
            e.Property(x => x.ErrorCodes).HasMaxLength(512).IsRequired();
        });
    }
}
