using System.IO.Compression;
using System.Text;
using ClosedXML.Excel;
using Microsoft.EntityFrameworkCore;
using SyntheticResultsDashboard.Application.Contracts;
using SyntheticResultsDashboard.Application.Services;
using SyntheticResultsDashboard.Domain.Entities;
using SyntheticResultsDashboard.Domain.Validation;
using SyntheticResultsDashboard.Infrastructure.Persistence;
using SyntheticResultsDashboard.Infrastructure.Services;
using SyntheticResultsDashboard.Infrastructure.Storage;
using SyntheticResultsDashboard.Infrastructure.Workbooks;
using Xunit;

namespace SyntheticResultsDashboard.Tests.Integration;

public sealed class ImportWorkflowTests
{
    [Fact]
    public void DemoTemplate_IsXlsxWithVisibleAndHiddenSheets_AndSixExpectedOutcomes()
    {
        using var temp = new TempArea();
        var path = temp.Write("sample.xlsx", new ClosedXmlReportWriter().WriteDemoTemplate());
        var reader = new SecureWorkbookReader();
        Assert.Equal(["DemoResults"], reader.InspectAndListVisibleSheets(path));
        Assert.Throws<PublicValidationException>(() => reader.ReadSheet(path, "HiddenDemo"));
        var rows = reader.ReadSheet(path, "DemoResults");
        Assert.Equal(6, rows.Count);
        var valid = WorkbookRules.Validate(rows);
        Assert.Equal(3, valid.Count(x => !x.IsValid));
        Assert.Contains("ScoreOutOfRange", valid[3].Errors);
        Assert.All(valid.Skip(4), x => Assert.Contains("DuplicateReferenceCode", x.Errors));
    }

    [Fact]
    public void SqliteMigration_AndServiceEndToEnd_PersistAndExportAfterRestart()
    {
        using var temp = new TempArea();
        var opts = new DbContextOptionsBuilder<ResultsDbContext>()
            .UseSqlite($"Data Source={Path.Combine(temp.Root, "results.db")}").Options;
        using var db = new ResultsDbContext(opts);
        db.Database.Migrate();
        Assert.Empty(db.ReferenceEntries);
        Assert.Empty(db.ImportRows);
        Assert.Empty(db.ImportBatches);
        var writer = new ClosedXmlReportWriter();
        var clock = new FixedClock();
        var service = new ResultsService(new SqliteAppData(db), new SecureWorkbookReader(), writer,
            new LocalTemporaryFileStore(temp.Root), new SingleProcessGate(), clock);
        Assert.Equal(4, service.SeedDemoAsync(CancellationToken.None).GetAwaiter().GetResult());
        Assert.Equal(0, service.SeedDemoAsync(CancellationToken.None).GetAwaiter().GetResult());
        Assert.Equal(4, db.ReferenceEntries.Count());
        var content = writer.WriteDemoTemplate();
        using var upload = new MemoryStream(content);
        var id = service.UploadAsync(upload, "fake-folder/sample.xlsx", content.LongLength, CancellationToken.None)
            .GetAwaiter().GetResult();
        var before = service.GetBatchAsync(id).GetAwaiter().GetResult()!;
        Assert.Equal(BatchStatus.Uploaded, before.Status);
        Assert.Empty(db.ImportRows);
        Assert.Equal(["DemoResults"], service.GetSheetsAsync(id, CancellationToken.None).GetAwaiter().GetResult());
        Assert.ThrowsAsync<PublicValidationException>(() => service.AnalyzeAsync(id, "HiddenDemo", CancellationToken.None))
            .GetAwaiter().GetResult();
        service.AnalyzeAsync(id, "DemoResults", CancellationToken.None).GetAwaiter().GetResult();
        Assert.Equal(6, before.TotalRows);
        Assert.Equal(1, before.MatchedCount);
        Assert.Equal(1, before.NotFoundCount);
        Assert.Equal(1, before.DepartmentMismatchCount);
        Assert.Equal(3, before.InvalidCount);
        Assert.Equal(BatchStatus.Completed, before.Status);
        Assert.ThrowsAsync<PublicValidationException>(() => service.AnalyzeAsync(id, "DemoResults", CancellationToken.None))
            .GetAwaiter().GetResult();
        Assert.Equal(6, db.ImportRows.Count());
        var matchedPage = service.GetPageAsync(id, RowOutcome.Matched, 1, CancellationToken.None).GetAwaiter().GetResult();
        Assert.Equal(1, matchedPage.Total);
        Assert.Equal(2, matchedPage.Rows.Single().SheetRowNumber);
        var exported = service.ExportAsync(id, CancellationToken.None).GetAwaiter().GetResult();
        Assert.EndsWith(".xlsx", exported.FileName);
        using var excel = new XLWorkbook(new MemoryStream(exported.Data));
        Assert.Equal(7, excel.Worksheet("Rows").LastRowUsed()!.RowNumber());
        Assert.Equal("TotalRows", excel.Worksheet("Summary").Cell(5, 1).GetString());
        Assert.Equal("6", excel.Worksheet("Summary").Cell(5, 2).GetString());
        Assert.All(excel.Worksheets.SelectMany(s => s.CellsUsed()), cell => Assert.False(cell.HasFormula));
        using var dbAgain = new ResultsDbContext(opts);
        Assert.Equal(4, dbAgain.ReferenceEntries.Count());
        Assert.Equal(6, dbAgain.ImportRows.Count());
        Assert.Equal(1, dbAgain.ImportBatches.Single().MatchedCount);
        Assert.False(File.Exists(Path.Combine(temp.Root, "App_Data", "StagedWorkbooks", before.StorageKey + ".tmp")));
    }

    [Fact]
    public void InvalidFile_AndOversizedArchive_AreRejectedWithoutPersistingRows()
    {
        using var temp = new TempArea();
        var reader = new SecureWorkbookReader();
        var invalid = temp.Write("invalid.xlsx", Encoding.UTF8.GetBytes("not a real excel file"));
        Assert.Throws<PublicValidationException>(() => reader.InspectAndListVisibleSheets(invalid));
        var huge = temp.Write("huge.xlsx", new byte[2 * 1024 * 1024 + 1]);
        Assert.Throws<PublicValidationException>(() => reader.InspectAndListVisibleSheets(huge));
    }

    [Fact]
    public void InvalidHeaderAndFormula_AreRejectedAsEntireSheet()
    {
        using var temp = new TempArea();
        var reader = new SecureWorkbookReader();
        using var doc = new XLWorkbook();
        var ws = doc.AddWorksheet("DemoResults");
        ws.Cell(1, 1).SetValue("WRONG");
        ws.Cell(1, 2).SetValue("DisplayName");
        ws.Cell(1, 3).SetValue("Department");
        ws.Cell(1, 4).SetValue("Score");
        ws.Cell(2, 1).SetValue("DEMO-001");
        ws.Cell(2, 2).SetValue("A");
        ws.Cell(2, 3).SetValue("SCI");
        ws.Cell(2, 4).SetValue(50);
        string path = Path.Combine(temp.Root, "bad.xlsx");
        doc.SaveAs(path);
        Assert.Throws<PublicValidationException>(() => reader.ReadSheet(path, "DemoResults"));
        ws.Cell(1, 1).SetValue("ReferenceCode");
        ws.Cell(2, 4).FormulaA1 = "=1+2";
        doc.SaveAs(path);
        Assert.Throws<PublicValidationException>(() => reader.ReadSheet(path, "DemoResults"));
    }

    [Fact]
    public void MissingTempFile_BecomesExpiredOnCleanup()
    {
        using var temp = new TempArea();
        var opts = new DbContextOptionsBuilder<ResultsDbContext>()
            .UseSqlite($"Data Source={Path.Combine(temp.Root, "results.db")}").Options;
        using var db = new ResultsDbContext(opts);
        db.Database.Migrate();
        var clock = new FixedClock();
        var store = new LocalTemporaryFileStore(temp.Root);
        var service = new ResultsService(new SqliteAppData(db), new SecureWorkbookReader(),
            new ClosedXmlReportWriter(), store, new SingleProcessGate(), clock);
        byte[] sample = new ClosedXmlReportWriter().WriteDemoTemplate();
        using var stream = new MemoryStream(sample);
        var id = service.UploadAsync(stream, "demo.xlsx", sample.Length, CancellationToken.None).GetAwaiter().GetResult();
        var batch = service.GetBatchAsync(id).GetAwaiter().GetResult()!;
        clock.Now = clock.Now.AddHours(2);
        service.CleanupAsync(CancellationToken.None).GetAwaiter().GetResult();
        Assert.Equal(BatchStatus.Expired, batch.Status);
        Assert.False(store.Exists(batch.StorageKey));
    }

    [Fact]
    public void ExternalRelationshipAndMacroArchive_AreRejected()
    {
        using var temp = new TempArea();
        var writer = new ClosedXmlReportWriter();
        byte[] source = writer.WriteDemoTemplate();
        var external = temp.Write("external.xlsx", source);
        using (var stream = new FileStream(external, FileMode.Open, FileAccess.ReadWrite))
        using (var zip = new ZipArchive(stream, ZipArchiveMode.Update))
        {
            var relationship = zip.CreateEntry("random/_rels/remote.rels");
            using var output = new StreamWriter(relationship.Open());
            output.Write("""
              <?xml version="1.0"?>
              <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
                <Relationship Id="remote" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink"
                              Target="https://invalid.example" TargetMode="External" />
              </Relationships>
              """);
        }
        Assert.Throws<PublicValidationException>(() => new SecureWorkbookReader().InspectAndListVisibleSheets(external));
        var macro = temp.Write("macro.xlsx", source);
        using (var stream = new FileStream(macro, FileMode.Open, FileAccess.ReadWrite))
        using (var zip = new ZipArchive(stream, ZipArchiveMode.Update))
        {
            var binary = zip.CreateEntry("xl/vbaProject.bin");
            using var output = binary.Open();
            output.WriteByte(0);
        }
        Assert.Throws<PublicValidationException>(() => new SecureWorkbookReader().InspectAndListVisibleSheets(macro));
    }

    [Fact]
    public void FailedSqliteInsert_RollsBackRowsAndCompletion()
    {
        using var temp = new TempArea();
        var opts = new DbContextOptionsBuilder<ResultsDbContext>()
            .UseSqlite($"Data Source={Path.Combine(temp.Root, "results.db")}").Options;
        using var db = new ResultsDbContext(opts);
        db.Database.Migrate();
        db.Database.ExecuteSqlRaw("""
          CREATE TRIGGER ForceFailure BEFORE INSERT ON ImportRows
          WHEN NEW.SheetRowNumber = 4 BEGIN SELECT RAISE(ABORT, 'SyntheticTestFailure'); END;
          """);
        var writer = new ClosedXmlReportWriter();
        var service = new ResultsService(new SqliteAppData(db), new SecureWorkbookReader(), writer,
            new LocalTemporaryFileStore(temp.Root), new SingleProcessGate(), new FixedClock());
        service.SeedDemoAsync(CancellationToken.None).GetAwaiter().GetResult();
        byte[] bytes = writer.WriteDemoTemplate();
        using var uploaded = new MemoryStream(bytes);
        var id = service.UploadAsync(uploaded, "demo.xlsx", bytes.Length, CancellationToken.None).GetAwaiter().GetResult();
        Assert.ThrowsAsync<DbUpdateException>(() => service.AnalyzeAsync(id, "DemoResults", CancellationToken.None))
            .GetAwaiter().GetResult();
        using var verification = new ResultsDbContext(opts);
        Assert.Equal(0, verification.ImportRows.Count());
        var batch = verification.ImportBatches.Single(x => x.Id == id);
        Assert.Equal(BatchStatus.Uploaded, batch.Status);
        Assert.Equal(0, batch.TotalRows);
    }

    [Fact]
    public void ExportDangerousText_StoresTextRatherThanFormula()
    {
        var fake = new ImportBatch { Status = BatchStatus.Completed, CompletedAtUtc = DateTimeOffset.UtcNow, TotalRows = 1 };
        var row = new ImportRow { BatchId = fake.Id, SheetRowNumber = 2, ReferenceCode = "DEMO-001",
            DisplayName = "=SUM(1,2)", Department = "SCI", Outcome = RowOutcome.Invalid,
            ErrorCodes = "InvalidDisplayName" };
        byte[] bytes = new ClosedXmlReportWriter().WriteReport(fake, [row]);
        using var book = new XLWorkbook(new MemoryStream(bytes));
        var cell = book.Worksheet("Rows").Cell(2, 3);
        Assert.False(cell.HasFormula);
        Assert.Contains("=SUM(1,2)", cell.GetString());
    }

    private sealed class FixedClock : IClock
    {
        public DateTimeOffset Now = new(2026, 11, 23, 14, 0, 0, TimeSpan.Zero);
        public DateTimeOffset UtcNow => Now;
    }

    private sealed class TempArea : IDisposable
    {
        public readonly string Root = Path.Combine(Path.GetTempPath(), "synthetic-results-tests-" + Guid.NewGuid().ToString("N"));
        public TempArea() => Directory.CreateDirectory(Root);
        public string Write(string name, byte[] bytes)
        {
            var path = Path.Combine(Root, name);
            File.WriteAllBytes(path, bytes);
            return path;
        }
        public void Dispose() { try { Directory.Delete(Root, recursive: true); } catch (IOException) { } }
    }
}
