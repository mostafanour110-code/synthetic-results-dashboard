using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using SyntheticResultsDashboard.Infrastructure.Persistence;
using Xunit;

namespace SyntheticResultsDashboard.Tests.Integration;

public sealed class HttpSecurityTests
{
    [Fact]
    public async Task FreshHomeShowsZeros_AndPostWithoutAntiforgeryIsRejected()
    {
        using var connection = new SqliteConnection("Data Source=:memory:");
        connection.Open();
        using var factory = new WebApplicationFactory<Program>().WithWebHostBuilder(builder =>
        {
            builder.ConfigureTestServices(services =>
            {
                services.RemoveAll<DbContextOptions<ResultsDbContext>>();
                services.AddDbContext<ResultsDbContext>(options => options.UseSqlite(connection));
            });
        });
        using var client = factory.CreateClient();
        var home = await client.GetAsync("/");
        home.EnsureSuccessStatusCode();
        string html = await home.Content.ReadAsStringAsync();
        Assert.Contains("نموذج تجريبي، بيانات مصطنعة فقط", html);
        Assert.Contains("لا توجد دفعات مكتملة بعد", html);
        using var scope = factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<ResultsDbContext>();
        Assert.Empty(await db.ReferenceEntries.ToListAsync());
        var forbiddenPost = await client.PostAsync("/Demo", new FormUrlEncodedContent([]));
        Assert.Equal(System.Net.HttpStatusCode.BadRequest, forbiddenPost.StatusCode);
        Assert.Empty(await db.ReferenceEntries.ToListAsync());
        var missingId = Guid.NewGuid();
        Assert.Equal(System.Net.HttpStatusCode.NotFound, (await client.GetAsync($"/Imports/Details/{missingId}")).StatusCode);
        Assert.Equal(System.Net.HttpStatusCode.BadRequest, (await client.GetAsync($"/Imports/Details/{missingId}?pageNumber=0")).StatusCode);
        Assert.Equal(System.Net.HttpStatusCode.BadRequest, (await client.GetAsync($"/Imports/Details/{missingId}?pageNumber=100001")).StatusCode);
    }
}
