using SyntheticResultsDashboard.Domain.Entities;
using SyntheticResultsDashboard.Domain.Validation;
using Xunit;

namespace SyntheticResultsDashboard.Tests.Unit;

public sealed class WorkbookRulesTests
{
    private static WorkbookRecord Record(int row, string code, string name, string department, decimal score) =>
        new(row, WorkbookCell.TextValue(code), WorkbookCell.TextValue(name),
            WorkbookCell.TextValue(department), WorkbookCell.NumberValue(score));

    [Fact]
    public void KnownSixRows_RespectPriorityAndCountInvariant()
    {
        var records = new[]
        {
            Record(2,"DEMO-001","اسم تجريبي 1","SCI",75.50m),
            Record(3,"DEMO-002","اسم تجريبي 2","SCI",60),
            Record(4,"DEMO-999","اسم تجريبي 3","ART",80),
            Record(5,"DEMO-003","اسم تجريبي 4","SCI",101),
            Record(6,"DEMO-004","اسم تجريبي 5","ART",50),
            Record(7,"DEMO-004","اسم تجريبي 6","ART",55)
        };
        var validated = WorkbookRules.Validate(records);
        var refs = new Dictionary<string, ReferenceEntry>
        {
            ["DEMO-001"] = new() { ReferenceCode = "DEMO-001", Department = "SCI" },
            ["DEMO-002"] = new() { ReferenceCode = "DEMO-002", Department = "ART" },
            ["DEMO-003"] = new() { ReferenceCode = "DEMO-003", Department = "SCI" },
            ["DEMO-004"] = new() { ReferenceCode = "DEMO-004", Department = "ART" }
        };
        var outcomes = validated.Select(x => WorkbookRules.Match(x, refs.GetValueOrDefault(x.ReferenceCode))).ToArray();
        Assert.Equal(new[] { RowOutcome.Matched, RowOutcome.DepartmentMismatch, RowOutcome.NotFound,
            RowOutcome.Invalid, RowOutcome.Invalid, RowOutcome.Invalid }, outcomes);
        Assert.Equal(3, outcomes.Count(x => x == RowOutcome.Invalid));
        Assert.Contains("ScoreOutOfRange", validated[3].Errors);
        Assert.All(validated.Skip(4), x => Assert.Contains("DuplicateReferenceCode", x.Errors));
        Assert.Equal(records.Length, outcomes.GroupBy(x => x).Sum(g => g.Count()));
    }

    [Fact]
    public void TrimmedDuplicate_RejectsBothOccurrences()
    {
        var rows = WorkbookRules.Validate([
            Record(2, " DEMO-001 ", "A", "SCI", 0),
            Record(3, "DEMO-001", "B", "SCI", 100)]);
        Assert.All(rows, x => Assert.Contains("DuplicateReferenceCode", x.Errors));
    }

    [Theory]
    [InlineData(-0.01, "ScoreOutOfRange")]
    [InlineData(100.01, "ScoreOutOfRange")]
    [InlineData(5.123, "ScorePrecisionExceeded")]
    public void InvalidScoreRejected(double score, string error)
    {
        var result = WorkbookRules.Validate([Record(2, "DEMO-001", "A", "SCI", (decimal)score)])[0];
        Assert.Contains(error, result.Errors);
    }

    [Theory]
    [InlineData(0)]
    [InlineData(100)]
    [InlineData(75.50)]
    public void ValidScoreAccepted(double score)
    {
        var result = WorkbookRules.Validate([Record(2, "DEMO-001", "A", "SCI", (decimal)score)])[0];
        Assert.True(result.IsValid);
    }

    [Fact]
    public void NumericReferenceRejected_LowercaseNotNormalized_TextScoreRejected()
    {
        var rows = WorkbookRules.Validate([
            new WorkbookRecord(2, WorkbookCell.NumberValue(123), WorkbookCell.TextValue("A"), WorkbookCell.TextValue("SCI"), WorkbookCell.NumberValue(20)),
            Record(3, "demo-001", "A", "SCI", 20),
            new WorkbookRecord(4, WorkbookCell.TextValue("DEMO-003"), WorkbookCell.TextValue("A"), WorkbookCell.TextValue("SCI"), WorkbookCell.TextValue("75"))]);
        Assert.Contains("InvalidReferenceCode", rows[0].Errors);
        Assert.Contains("InvalidReferenceCode", rows[1].Errors);
        Assert.Contains("InvalidScoreType", rows[2].Errors);
    }

    [Fact]
    public void DifferentDisplayNameDoesNotBlockMatched()
    {
        var row = WorkbookRules.Validate([Record(2,"DEMO-001","اسم مختلف","SCI",25)])[0];
        var outcome = WorkbookRules.Match(row, new ReferenceEntry { ReferenceCode = "DEMO-001", Department = "SCI", DisplayName = "اسم آخر" });
        Assert.Equal(RowOutcome.Matched, outcome);
    }
}
